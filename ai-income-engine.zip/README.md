# AI Income Engine

## Setup Instructions
1. Fill in the `.env` file
2. Connect APIs
3. Trigger the workflow
4. Profit.